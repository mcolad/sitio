<?php
  require __DIR__  . '/vendor/autoload.php';
  MercadoPago\SDK::setClientId("7254641100100295");
  MercadoPago\SDK::setClientSecret("7LPUq0tphZeAEJc5uIpa3SkEavawqys1");

  # Create a preference object
  $preference = new MercadoPago\Preference();
  # Create an item object
  $item = new MercadoPago\Item();
  $item->id = "1234";
  $item->title = "Durable Bronze Car";
  $item->quantity = 7;
  $item->currency_id = "ARS";
  $item->unit_price = 2.62;
  # Create a payer object
  $payer = new MercadoPago\Payer();
  $payer->email = "jack@hotmail.com";
  # Setting preference properties
  $preference->items = array($item);
  $preference->payer = $payer;
  # Save and posting preference
  $preference->save();
  
  echo $item->title;
?>

<html>
    <head>
        <title>Pagar</title>
    </head>
    <body>
        <a href="<?php echo $preference->init_point; ?>">Pay</a>
    </body>
</html>
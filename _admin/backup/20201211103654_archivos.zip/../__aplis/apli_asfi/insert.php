<?
mysqli_query($cnx, "UPDATE apli_$apli SET titulo = '".strtoupper($_POST['apellidos']).", ".$_POST['nombres']." - ".$_POST['dni']."' WHERE id_apli_$apli = '".$id."';");
?>
<?
mysqli_query($cnx, "UPDATE apli_$apli SET titulo = '".$arraytags['20201117084442'][substr($_POST['20201117084442'], 0, 14)]."' WHERE id_apli_$apli = '".$id."';");
?>
<?
mysqli_query($cnx, "UPDATE apli_$apli SET titulo = '".$_POST['familiar']."' WHERE id_apli_$apli = '".$id."';");
?>
<?
			echo substr('1234567898abcd', -4);
?>
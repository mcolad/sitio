<?
if(unlink($_GET['borrar'])){ echo "eliminado!"; };

?>